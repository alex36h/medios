<h1 class="text-center"><span><?php echo $varAcceso['nombre'] ;?></span></h1>
<hr>

<ul class="nav nav-tabs" id="myTab" role="tablist">
  <li class="nav-item">
    <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">Example #1</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="false">Example #2</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" id="contact-tab" data-toggle="tab" href="#contact" role="tab" aria-controls="contact" aria-selected="false">Example #3</a>
  </li>
</ul>
<div class="tab-content" id="myTabContent">
  <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">

  <div class="row">
      <div class="col-md-6">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer laoreet magna diam, a gravida lacus hendrerit at. Nullam maximus urna arcu, eget tempor leo blandit non. Proin luctus, tortor non molestie ullamcorper, lacus sem imperdiet nibh, sed egestas tortor leo at nunc. Nunc condimentum iaculis elit sed efficitur. Integer pretium ullamcorper metus, nec maximus odio lacinia maximus. Sed id tempus orci. Praesent commodo eget massa congue rhoncus. Nulla et eros eget nibh porttitor porttitor nec vitae enim. Morbi eros libero, pellentesque sed odio nec, gravida cursus magna. Ut eu libero sed dui hendrerit bibendum et sed ante. Morbi et eros at quam finibus hendrerit vitae et augue. Maecenas auctor quam lorem, ac dictum odio ullamcorper in. Donec pretium urna vitae est convallis semper ut in sem.

Sed vulputate tincidunt pellentesque. Etiam et rutrum ipsum. Phasellus malesuada interdum varius. Curabitur quis molestie magna. Cras ut porta magna. Aliquam erat volutpat. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur quis blandit dui, nec condimentum arcu. Integer nec purus eu orci malesuada molestie. Aliquam ante velit, mollis vel ultrices eget, imperdiet vel erat. Nulla facilisi. Donec sed justo eu ex tincidunt faucibus sit amet at libero. Maecenas porta, sapien non fringilla vestibulum, felis ipsum sodales felis, nec interdum sapien ligula quis erat. Sed ultrices eget est sit amet pretium. Nam aliquet non urna ut dapibus. Interdum et malesuada fames ac ante ipsum primis in faucibus.

Suspendisse potenti. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque sed metus vitae ligula accumsan consectetur quis quis lacus. Maecenas ac tortor eu eros mattis fringilla. Cras tempor sed lacus quis volutpat. Sed bibendum, ipsum id viverra rhoncus, risus quam pulvinar tortor, at commodo enim felis tempor sapien. Curabitur vel rhoncus nulla. Maecenas varius ac risus nec pellentesque. In scelerisque semper ante, ac posuere urna. In bibendum est id facilisis lobortis. Etiam a quam finibus, suscipit magna non, rutrum orci. Quisque at arcu id quam tempor pretium nec ac dolor. Aenean ullamcorper est nec diam iaculis accumsan.

Morbi ultrices leo eget varius ornare. Nulla facilisi. Vivamus vehicula lectus ipsum, sit amet posuere turpis consectetur in. Interdum et malesuada fames ac ante ipsum primis in faucibus. Cras in feugiat tortor. Mauris semper orci sit amet ipsum blandit condimentum. Nullam non velit lobortis nisl porta porttitor scelerisque molestie ligula. Vestibulum tempus libero massa, eu pellentesque mauris congue sed. Proin sit amet nibh porta, varius nulla nec, fermentum nibh. Aliquam placerat cursus ipsum, ut efficitur nisl efficitur id.

Aliquam eros ante, iaculis sed lectus non, mollis consequat lorem. Praesent vitae nulla a risus imperdiet pharetra. Praesent dapibus nisi eget sapien interdum posuere. In sodales dictum dui, sed vehicula libero suscipit et. Nunc bibendum, arcu sed feugiat hendrerit, diam turpis vestibulum turpis, et vestibulum arcu arcu non enim. Morbi faucibus et erat non ornare. In sapien diam, suscipit id tincidunt sit amet, consequat vitae ligula.</div>

<div class="col-md-6">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer laoreet magna diam, a gravida lacus hendrerit at. Nullam maximus urna arcu, eget tempor leo blandit non. Proin luctus, tortor non molestie ullamcorper, lacus sem imperdiet nibh, sed egestas tortor leo at nunc. Nunc condimentum iaculis elit sed efficitur. Integer pretium ullamcorper metus, nec maximus odio lacinia maximus. Sed id tempus orci. Praesent commodo eget massa congue rhoncus. Nulla et eros eget nibh porttitor porttitor nec vitae enim. Morbi eros libero, pellentesque sed odio nec, gravida cursus magna. Ut eu libero sed dui hendrerit bibendum et sed ante. Morbi et eros at quam finibus hendrerit vitae et augue. Maecenas auctor quam lorem, ac dictum odio ullamcorper in. Donec pretium urna vitae est convallis semper ut in sem.

Sed vulputate tincidunt pellentesque. Etiam et rutrum ipsum. Phasellus malesuada interdum varius. Curabitur quis molestie magna. Cras ut porta magna. Aliquam erat volutpat. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur quis blandit dui, nec condimentum arcu. Integer nec purus eu orci malesuada molestie. Aliquam ante velit, mollis vel ultrices eget, imperdiet vel erat. Nulla facilisi. Donec sed justo eu ex tincidunt faucibus sit amet at libero. Maecenas porta, sapien non fringilla vestibulum, felis ipsum sodales felis, nec interdum sapien ligula quis erat. Sed ultrices eget est sit amet pretium. Nam aliquet non urna ut dapibus. Interdum et malesuada fames ac ante ipsum primis in faucibus.

Suspendisse potenti. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque sed metus vitae ligula accumsan consectetur quis quis lacus. Maecenas ac tortor eu eros mattis fringilla. Cras tempor sed lacus quis volutpat. Sed bibendum, ipsum id viverra rhoncus, risus quam pulvinar tortor, at commodo enim felis tempor sapien. Curabitur vel rhoncus nulla. Maecenas varius ac risus nec pellentesque. In scelerisque semper ante, ac posuere urna. In bibendum est id facilisis lobortis. Etiam a quam finibus, suscipit magna non, rutrum orci. Quisque at arcu id quam tempor pretium nec ac dolor. Aenean ullamcorper est nec diam iaculis accumsan.

Morbi ultrices leo eget varius ornare. Nulla facilisi. Vivamus vehicula lectus ipsum, sit amet posuere turpis consectetur in. Interdum et malesuada fames ac ante ipsum primis in faucibus. Cras in feugiat tortor. Mauris semper orci sit amet ipsum blandit condimentum. Nullam non velit lobortis nisl porta porttitor scelerisque molestie ligula. Vestibulum tempus libero massa, eu pellentesque mauris congue sed. Proin sit amet nibh porta, varius nulla nec, fermentum nibh. Aliquam placerat cursus ipsum, ut efficitur nisl efficitur id.

Aliquam eros ante, iaculis sed lectus non, mollis consequat lorem. Praesent vitae nulla a risus imperdiet pharetra. Praesent dapibus nisi eget sapien interdum posuere. In sodales dictum dui, sed vehicula libero suscipit et. Nunc bibendum, arcu sed feugiat hendrerit, diam turpis vestibulum turpis, et vestibulum arcu arcu non enim. Morbi faucibus et erat non ornare. In sapien diam, suscipit id tincidunt sit amet, consequat vitae ligula.</div>
</div>

  </div>
  <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">...</div>
  <div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="contact-tab">...</div>
</div>