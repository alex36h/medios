<?php

$clave_cifrada = hash("sha512", "m7x". "12345" );
echo $clave_cifrada;